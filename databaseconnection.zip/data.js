function displayData() {
    let a = document.getElementById('displaychange');
    if(a.style.display == "none") {
        a.style.display = "inline-block";
    }
    else {
        a.style.display = "none";
    }
}